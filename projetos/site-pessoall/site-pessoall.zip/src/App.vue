<template>
    <router-view/>
</template>

<style>
body{
  margin:0;
  padding: 0;
}
#app {
  font-family: 'Roboto', sans-serif;
  -webkit-font-smoothing: antialiased;
  -moz-osx-font-smoothing: grayscale;
  text-align: center;
  color: #fff;
}
#nav a.router-link-exact-active {
  color: #42b983;
}
h1{
  font-size: 89px;
}
h2{
  font-size: 67px;
}
h3{
  font-size: 50px;
}
h4{
  font-size: 37px;
}
h5{
  font-size: 28px;
}
h6{
  font-size: 21px;
}
p{
  font-size: 16px;
}
@import url('https://fonts.googleapis.com/css2?family=Roboto:ital,wght@0,100;0,300;0,400;0,500;0,700;0,900;1,100;1,300;1,400;1,500;1,700;1,900&display=swap');
</style>
