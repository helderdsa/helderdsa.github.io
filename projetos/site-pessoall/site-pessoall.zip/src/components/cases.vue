<template>
    <div>
        <h3>aqui é a área dos projetos mas ainda não acabei</h3>
    </div>
</template>
<script>
export default {
    
}
</script>
<style scoped>
div{
    background-color: #F80040;
}
</style>